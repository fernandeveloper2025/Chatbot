import speech_recognition as sr
from google import genai
import pyttsx3


# función de reconocer voz
def reconocer_voz():
    # Crear un objeto de reconocimiento de voz
    r = sr.Recognizer()

    # usar el microfono para escuchar
    with sr.Microphone() as source:
        print("Ajustando el ruido del ambiente...")
        r.adjust_for_ambient_noise(source, duration=1)
        print("Escuchando... di algo.")
        audio = r.listen(source)
    
        try:
            print("Reconociendo...")
            texto = r.recognize_google(audio, language="es-ES") # google nos ayuda con esto
            print(f"lo que dijiste fue: {texto}")
            return texto
        except sr.UnknownValueError as ex:
            print(f"No se pudo conectar al servicio de google. Error: {ex}")
            return ""
        
    
def obtener_respuesta_fromGemini(texto):
    try:
        client = genai.Client(api_key="AIzaSyARLy1mmxpwDUmotuuDRxebmBZWF3IXr1U")
        modelo = "gemini-2.0-flash"

        respuesta = client.models.generate_content(
            model=modelo,
            contents=texto)
        return respuesta.text
    except Exception as ex:
        print(f"Error con el servicio de gemini. Error={ex}")
        return "Lo siento no tengo una respuesta"

# función para hablar utilizando pyttsx3
def hablar(texto):
    engine = pyttsx3.init()
    engine.setProperty('rate', 150) # velocidad de habla|
    engine.setProperty('volume', 1) 
    engine.say(texto)
    engine.runAndWait()

# función principal para escuchar, procesar y responder
def asistenteVirtual():
    while True:
        # escuchar
        texto = reconocer_voz()
        print(f"He reconocido lo siguiente que has dicho: {texto}")
        
        # comando de salida
        if texto.lower() == "salir":
            print("¡Adiós!")
            hablar("Adiós!")
            break
        
        # procesamiento y respuesta
        respuesta = obtener_respuesta_fromGemini(texto)
        print(f"Respuesta de la IA: {respuesta}")
        hablar(respuesta)

if __name__ == "__main__":
    asistenteVirtual()