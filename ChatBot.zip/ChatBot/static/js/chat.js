// Variables globales para mantener la información del usuario
let userData = {
  nombre_cliente: null,
  telefono: null,
  documento: null,
  numero_servicio: null,
};

function validateForm() {
  const nombre = document.getElementById("nombre_cliente").value.trim();
  const telefono = document.getElementById("telefono").value.trim();
  const documento = document.getElementById("documento").value.trim();

  if (!nombre || !telefono || !documento) {
    alert("Por favor complete los campos obligatorios");
    return false;
  }

  if (nombre.length < 3) {
    alert("Por favor ingrese un nombre válido");
    return false;
  }

  if (!/^\d{10,}$/.test(telefono)) {
    alert("Por favor ingrese un número de teléfono válido (mínimo 10 dígitos)");
    return false;
  }

  return true;
}

function startChat() {
  if (!validateForm()) return;

  // Guardar datos del usuario
  userData = {
    nombre_cliente: document.getElementById("nombre_cliente").value.trim(),
    telefono: document.getElementById("telefono").value.trim(),
    documento: document.getElementById("documento").value.trim(),
    numero_servicio:
      document.getElementById("numero_servicio").value.trim() || null,
  };

  // Inicializar el chat
  document.getElementById("initial-form").style.display = "none";
  document.getElementById("chat-interface").style.display = "block";

  // Mensaje de bienvenida personalizado
  const chatBox = document.getElementById("chat-box");
  chatBox.innerHTML = `<div class="message bot-message">¡Hola ${userData.nombre_cliente}! ¿En qué puedo ayudarte hoy?</div>`;

  // Enviar datos del usuario al servidor
  fetch("/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      type: "init",
      userData: userData,
    }),
  });
}

function sendMessage() {
  const userInput = document.getElementById("user-input");
  const message = userInput.value.trim();
  if (!message) return;

  const chatBox = document.getElementById("chat-box");
  chatBox.innerHTML += `<div class="message user-message">${message}</div>`;
  userInput.value = "";

  fetch("/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      message: message,
      userData: userData, // Incluir datos del usuario en cada mensaje
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      chatBox.innerHTML += `<div class="message bot-message">${data.response}</div>`;
      chatBox.scrollTop = chatBox.scrollHeight;
    });
}

// Permitir envío con Enter
document
  .getElementById("user-input")
  .addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
      sendMessage();
    }
  });
