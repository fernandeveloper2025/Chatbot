// Variables globales para mantener la información del usuario
let userData = {
  nombre_cliente: null,
  telefono: null,
  documento: null,
  numero_servicio: null,
};

let typingTimer = null;
let isTyping = false;

function validateForm() {
  const nombre = document.getElementById("nombre_cliente").value.trim();
  const telefono = document.getElementById("telefono").value.trim();
  const documento = document.getElementById("documento").value.trim();

  if (!nombre || !telefono || !documento) {
    alert("Por favor complete los campos obligatorios");
    return false;
  }

  if (nombre.length < 3) {
    alert("Por favor ingrese un nombre válido");
    return false;
  }

  if (!/^\d{10,}$/.test(telefono)) {
    alert("Por favor ingrese un número de teléfono válido (mínimo 10 dígitos)");
    return false;
  }

  return true;
}

function startChat() {
  if (!validateForm()) return;

  // Guardar datos del usuario
  userData = {
    nombre_cliente: document.getElementById("nombre_cliente").value.trim(),
    telefono: document.getElementById("telefono").value.trim(),
    documento: document.getElementById("documento").value.trim(),
    numero_servicio:
      document.getElementById("numero_servicio").value.trim() || null,
  };

  // Inicializar el chat
  document.getElementById("initial-form").style.display = "none";
  document.getElementById("chat-interface").style.display = "block";

  // Mensaje de bienvenida personalizado
  const welcomeMessage = `¡Hola ${userData.nombre_cliente}! ¿En qué puedo ayudarte hoy?`;
  const chatBox = document.getElementById("chat-box");

  // Activar avatar animado para el mensaje inicial
  switchAvatar("talking");

  chatBox.innerHTML = `<div class="message bot-message">${welcomeMessage}</div>`;

  // Hacer que el bot hable el mensaje de bienvenida
  speakBotResponse(welcomeMessage);

  // Volver al avatar estático después del mensaje inicial
  setTimeout(() => {
    switchAvatar("static");
  }, 2000);

  // Enviar datos del usuario al servidor
  fetch("/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      type: "init",
      userData: userData,
    }),
  });
}

// Agregar estas funciones al inicio del archivo
function showTypingIndicator() {
  const chatBox = document.getElementById("chat-box");
  const avatar = document.querySelector(".avatar-container img");

  // Pausar la animación del avatar
  avatar.classList.remove("active");
  avatar.classList.add("paused");

  // Mostrar indicador de escritura
  const typingDiv = document.createElement("div");
  typingDiv.className = "typing-indicator";
  typingDiv.innerHTML = `
      <span></span>
      <span></span>
      <span></span>
  `;
  chatBox.appendChild(typingDiv);
  typingDiv.style.display = "block";
  chatBox.scrollTop = chatBox.scrollHeight;
}

function hideTypingIndicator() {
  const typingIndicator = document.querySelector(".typing-indicator");
  if (typingIndicator) {
    typingIndicator.remove();
  }
}

function activateAvatar() {
  const avatar = document.querySelector(".avatar-container img");
  avatar.classList.remove("paused");
  avatar.classList.add("active");
}

function deactivateAvatar() {
  const avatar = document.querySelector(".avatar-container img");
  avatar.classList.remove("active");
  avatar.classList.add("paused");
}

// Función para manejar cuando el usuario está escribiendo
function handleUserTyping() {
  const chatBox = document.getElementById("chat-box");
  const typingIndicator = document.querySelector(".typing-indicator");

  // Si no estaba escribiendo antes, mostrar el indicador
  if (!isTyping) {
    isTyping = true;
    typingIndicator.style.display = "block";
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  // Limpiar el timer anterior si existe
  if (typingTimer) {
    clearTimeout(typingTimer);
  }

  // Establecer nuevo timer
  typingTimer = setTimeout(() => {
    isTyping = false;
    typingIndicator.style.display = "none";
  }, 1000); // Ocultar después de 1 segundo sin escribir
}

// Función para cambiar entre avatar estático y animado
function switchAvatar(state) {
  const avatarImg = document.querySelector(".avatar-container img");
  if (state === "talking") {
    avatarImg.src = "/static/avatar-talking.gif";
  } else {
    avatarImg.src = "/static/avatar-static.png";
  }
}
// Web Speech para convertir voz a texto
document.getElementById("voice-button").addEventListener("click", function () {
  const recognition = new (window.SpeechRecognition ||
    window.webkitSpeechRecognition)();
  recognition.lang = "es-ES";

  recognition.onstart = function () {
    console.log("🎤 Escuchando...");
  };

  recognition.onresult = function (event) {
    const transcript = event.results[0][0].transcript;
    document.getElementById("user-input").value = transcript;
    sendMessage();
  };

  recognition.onerror = function (event) {
    console.log("Error de reconocimiento: ", event.error);
  };

  recognition.start();
});

// speechSynthesis para que el bot hable:
function speakResponse(response) {
  const synth = window.speechSynthesis;
  const utterance = new SpeechSynthesisUtterance(response);
  utterance.lang = "es-ES";
  synth.speak(utterance);
}

// Función para que el bot hable
function speakBotResponse(text) {
  const synth = window.speechSynthesis;
  // Cancelar cualquier voz anterior que esté reproduciéndose
  synth.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "es-ES";

  // Obtener voces disponibles
  const voices = synth.getVoices();
  // Intentar encontrar una voz en español
  const spanishVoice = voices.find((voice) => voice.lang.startsWith("es"));
  if (spanishVoice) {
    utterance.voice = spanishVoice;
  }

  synth.speak(utterance);
}

async function sendMessage() {
  const userInput = document.getElementById("user-input");
  const message = userInput.value.trim();
  if (!message) return;

  const chatBox = document.getElementById("chat-box");
  const typingIndicator = document.querySelector(".typing-indicator");

  // Ocultar indicador de escritura
  typingIndicator.style.display = "none";
  isTyping = false;

  chatBox.innerHTML += `<div class="message user-message">${message}</div>`;
  userInput.value = "";
  chatBox.scrollTop = chatBox.scrollHeight;

  // Mostrar indicador de escritura del bot
  showTypingIndicator();
  switchAvatar("static");

  try {
    const response = await fetch("/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: message,
        userData: userData,
      }),
    });
    const data = await response.json();

    // Ocultar indicador de escritura
    hideTypingIndicator();

    // Activar avatar animado
    switchAvatar("talking");

    // Mostrar respuesta del bot
    chatBox.innerHTML += `<div class="message bot-message">${data.response}</div>`;
    chatBox.scrollTop = chatBox.scrollHeight;

    // Hacer que el bot hable la respuesta
    speakBotResponse(data.response);

    // Volver al avatar estático después de un tiempo
    setTimeout(() => {
      switchAvatar("static");
    }, 2000);
  } catch (error) {
    console.error("Error:", error);
    hideTypingIndicator();
    switchAvatar("static");
  }
}

// Agregar evento para detectar escritura
document
  .getElementById("user-input")
  .addEventListener("input", handleUserTyping);

// Permitir envío con Enter
document
  .getElementById("user-input")
  .addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
      sendMessage();
    }
  });
